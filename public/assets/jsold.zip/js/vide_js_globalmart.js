function initplayers() {
    var videojselements = document.getElementsByClassName("video-js");
    if (videojselements) {
        for (var i = 0; i < videojselements.length; i++) {
            var element = videojselements[i];
            var player = videojs(element.id);
            var poster = element.getAttribute('poster');
            if (poster) {
                player.poster(poster);
            }
        }
    }
}

initplayers();
